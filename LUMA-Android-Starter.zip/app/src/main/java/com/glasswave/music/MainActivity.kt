package com.glasswave.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF171716)
private val GlassWhite = Color(0xCCFFFFFF)
private val GlassEdge = Color(0x80FFFFFF)
private val Muted = Color(0xFF777773)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LumaApp() }
    }
}

@Composable
fun LumaApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var playing by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(
        background = Color(0xFFE5E2DC),
        surface = Color(0xFFF3F1EC),
        primary = Color(0xFF272725),
        onBackground = Ink,
        onSurface = Ink
    )) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.linearGradient(
                    listOf(Color(0xFFF7F5F0), Color(0xFFBDBBB4), Color(0xFFE9E6DF), Color(0xFF8D8B85))
                )
            )
        ) {
            // Abstract monochrome "glass" atmosphere behind the UI.
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 28.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LUMA", fontSize = 13.sp, letterSpacing = 4.sp, fontWeight = FontWeight.SemiBold)
                        Text("Music, in pure glass.", fontSize = 12.sp, color = Muted)
                    }
                    GlassIcon(Icons.Rounded.Person, "Profile") {}
                }
                Spacer(Modifier.height(24.dp))

                when (selectedTab) {
                    "Home" -> HomeScreen(onConnect = { connected = true }, connected = connected)
                    "Search" -> SearchScreen()
                    "Library" -> LibraryScreen()
                }

                Spacer(Modifier.weight(1f))
                MiniPlayer(playing = playing, onToggle = { playing = !playing })
                Spacer(Modifier.height(12.dp))
                GlassPanel(Modifier.fillMaxWidth(), radius = 28.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NavItem("Home", Icons.Rounded.Home, selectedTab == "Home") { selectedTab = "Home" }
                        NavItem("Search", Icons.Rounded.Search, selectedTab == "Search") { selectedTab = "Search" }
                        NavItem("Library", Icons.Rounded.LibraryMusic, selectedTab == "Library") { selectedTab = "Library" }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onConnect: () -> Unit, connected: Boolean) {
    Column {
        Text("Good evening", fontSize = 29.sp, fontWeight = FontWeight.Medium, letterSpacing = (-0.8).sp)
        Text("Let the music flow", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(18.dp))
        GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                Text("Search songs, artists, playlists…", color = Muted, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("Recently played", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AlbumTile("Midnight\nVibes", "◌", Modifier.weight(1f))
            AlbumTile("Chill\nHits", "☾", Modifier.weight(1f))
            AlbumTile("Good\nDays", "✳", Modifier.weight(1f))
        }
        Spacer(Modifier.height(22.dp))
        Text("Your music, your mood", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassArtwork(54)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Connect Spotify", fontWeight = FontWeight.SemiBold)
                    Text(if (connected) "Connection setup next" else "Sign in to access your music", color = Muted, fontSize = 12.sp)
                }
                Button(onClick = onConnect, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF292927))) {
                    Text(if (connected) "Selected" else "Connect", color = Color.White)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Spotify login and playback will be added in the next build step.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SearchScreen() {
    Column {
        Text("Search", fontSize = 30.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(18.dp))
        GlassPanel(Modifier.fillMaxWidth(), 22.dp) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Search, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                Text("Search Spotify", color = Muted)
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Browse your sound", fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        listOf("Made for you", "New releases", "Mood", "Focus", "Podcasts", "Albums").forEach {
            GlassPanel(Modifier.fillMaxWidth().padding(bottom = 9.dp), 18.dp) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.GraphicEq, null)
                    Spacer(Modifier.width(12.dp))
                    Text(it, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen() {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Your Library", fontSize = 29.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            GlassIcon(Icons.Rounded.Add, "Add playlist") {}
        }
        Spacer(Modifier.height(18.dp))
        listOf("Liked Songs", "Chill Vibes", "Focus Flow", "Late Night", "Workout").forEachIndexed { index, title ->
            GlassPanel(Modifier.fillMaxWidth().padding(bottom = 10.dp), 20.dp) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassArtwork(48, index)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, fontWeight = FontWeight.SemiBold)
                        Text(if (index == 0) "Your liked tracks" else "Playlist · Spotify", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun AlbumTile(title: String, symbol: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.9f).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFF8F7F2), Color(0xFFBDBBB4), Color(0xFFE7E3DB))))
                .border(1.dp, GlassEdge, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) { Text(symbol, fontSize = 36.sp, color = Color(0xFF77766F)) }
        Spacer(Modifier.height(7.dp))
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Medium, lineHeight = 15.sp)
    }
}

@Composable
private fun GlassArtwork(size: Int, variant: Int = 0) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(15.dp))
            .background(Brush.linearGradient(
                when (variant % 3) {
                    0 -> listOf(Color(0xFFF9F8F3), Color(0xFFB8B6AF), Color(0xFFE8E5DD))
                    1 -> listOf(Color(0xFFE4E1D9), Color(0xFF999890), Color(0xFFF5F2EB))
                    else -> listOf(Color(0xFFCBC9C1), Color(0xFFF8F7F2), Color(0xFFA6A49D))
                }
            )).border(1.dp, GlassEdge, RoundedCornerShape(15.dp)),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Waves, null, tint = Color(0xFF77766F), modifier = Modifier.size((size / 2).dp)) }
}

@Composable
private fun MiniPlayer(playing: Boolean, onToggle: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth(), 24.dp) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassArtwork(48)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Better Together", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Connect Spotify to play music", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = onToggle) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, contentDescription = "Play or pause")
            }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (selected) Ink else Muted)
        Text(label, fontSize = 11.sp, color = if (selected) Ink else Muted)
    }
}

@Composable
private fun GlassIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(Color(0x80FFFFFF))
            .border(1.dp, GlassEdge, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = description, tint = Ink) }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, radius: androidx.compose.ui.unit.Dp = 24.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(radius))
            .background(Brush.linearGradient(listOf(Color(0xDDFBFAF6), Color(0xA6E1DFD7), Color(0xC8FFFFFF))))
            .border(1.dp, GlassEdge, RoundedCornerShape(radius)),
        content = content
    )
}
